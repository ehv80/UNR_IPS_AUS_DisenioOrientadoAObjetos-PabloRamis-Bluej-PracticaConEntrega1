import java.util.ArrayList;

/**
 * Manage the stock in a business.
 * The stock is described by zero or more Products.
 * 
 * @author Ezequiel Hern�n Villanueva 
 * @version 16/10/2005
 */
public class StockManager
{
    // A list of the products.
    private ArrayList stock;

    /**
     * Initialise the stock manager.
     */
    public StockManager()
    {
        stock = new ArrayList();
    }

    /**
     * Add a product to the list.
     * @param item The item to be added.
     * -------------------------------------------------------------------------
     * Modificaci�n requerida por el ejercicio 4.36 de la pag 99 para lograr que
     * no se puedan ingresar a la lista dos productos distintos con un mismo "id".
     * Utilizo un booleano seteado en false. Comienzo a recorrer cada producto del
     * ArrayList "stock" y lo guardo en un objeto Product denominado "temp". Si 
     * "temp" es distinto de "null" y si "temp.getID()" es igual a "item.getID()"
     * entonces estamos en el caso de querer ingresar un producto cuyo "id" ya 
     * existe, por lo que seteo "existe" en true , imprimo un mensaje de error y
     * corto la ejecuci�n del bucle con un "break".
     * Si el bucle se recorre totalmente, es decir que el "id" de "item" no lo
     * posee ninguno de los productos del ArrayList, es decir "existe" es false
     * entoces puedo agregar ese producto sin peligro de que hayan dos productos 
     * distintos con un mismo "id".     */
    public void addProduct(Product item)
    {
        boolean existe = false;
        for( int i=0 ; i < stock.size() ; i++ )
        {
            Product temp = (Product) stock.get(i);
            if( temp != null )
            {
                if( temp.getID() == item.getID() )
                {
                    existe = true;
                    System.out.println("No puede ingresar 2 productos distintos con un mismo id!!!");
                    break;
                }
            }
        }
        if( existe == false )
        {
            stock.add(item);
        }
    }
    
    /**
     * Receive a delivery of a particular product.
     * Increase the quantity of the product by the given amount.
     * @param id The ID of the product.
     * @param amount The amount to increase the quantity by.
     * -------------------------------------------------------------------------
     * M�todo "delivery( int id , int amount )" requerido por el ejercicio 4.35 
     * de la pag. 99. Toma como par�metros un identificador "id" y un valor 
     * "amount" que representa la cantidad que se ha recibido y puesto en stock
     * de ese producto. Utilizo un Product "aux" en el que guardo la salida del
     * m�todo "findProduct( int id )". Si "aux" es distinto a "null" entonces 
     * incremento la cantidad de ese producto a trav�s del m�todo 
     * "aux.increaseQuantity( amount )" con el monto indicado en "amount". 
     * Si "aux" resulta ser "null" entonces imprimo un mensaje de error en 
     * pantalla:
     * System.out.println("Intento de incremento de un producto inexistente!!!"); */
    public void delivery(int id, int amount)
    {
        Product aux = findProduct( id );
        if( aux != null )
        {
            aux.increaseQuantity( amount );
        }
        else
        {
            System.out.println("Intento de incremento de un producto inexistente!!!");
        }
    }
    
    /**
     * Try to find a product in the stock with the given id.
     * @return The identified product, or null if there is none
     * with a matching ID.
     * ------------------------------------------------------------------------------
     * M�todo "findProduct( int id )" requerido por el ejercicio 4.33 de la pag. 99
     * Toma como par�metro un identificador de producto "id".
     * Voy a recorrer todo el ArrayList denominado "stock" , guardo cada producto 
     * del ArrayList en un objeto Product denominado "temp" haciendo un cast.
     * Me fijo si ese Product es distinto a "null", luego uso el m�todo "getID()"
     * para ver si es igual al obtenido como par�metro, de ser as� este es el 
     * producto buscado entonces lo retorno. De lo contrario retorno "null".
     */
    public Product findProduct(int id)
    {
        for( int i=0 ; i < stock.size() ; i++ )
        {
            Product temp = (Product) stock.get( i );
            if( temp != null )
            {
                if( temp.getID() == id )
                {
                    return temp;
                }
            }
        }
        return null;
    }
    
    /** Nuevo m�todo requerido por el ejercicio 4.36 de la pag. 99 que implementa
     *  el m�todo "findProduct( String name )" pero de una manera distinta, tomando 
     *  como par�metro la cadena de caracteres "name".
     *  Utilizo un bucle para recorrer todo los Products del ArrayList, el m�todo 
     *  "string1.equals( name )" para comparar las cadenas "name" con "temp.getName()".
     *  Si "temp" es distinto de "null" y "temp.getName()" es igual a "name" entonces
     *  retorno "temp". De lo contrario si se ha recorrido todo el ArrayList sin 
     *  encontrar un Product con igual nombre que "name" entonces retorna "null".  */
     public Product findProduct( String name )
     {
         for( int i=0 ; i < stock.size() ; i++ )
         {
             Product temp = (Product) stock.get(i);
             if( temp != null )
             {
                 String string1 = temp.getName();
                 if( string1.equals( name ) )
                 {
                     return temp;
                 }
             }
         }
         return null;
     }
    
    /**
     * Locate a product with the given ID, and return how
     * many of this item are in stock. If the ID does not
     * match any product, return zero.
     * @param id The ID of the product.
     * @return The quantity of the given product in stock.
     * -----------------------------------------------------------------------
     * M�todo requerido por el ejercicio 4.34 de la pag. 99. Utilizo un 
     * Product denominado "buscado" para guardar la salida del m�todo
     * "findProduct( int id )" de este modo obtengo el producto que tiene ese
     * n�mero identificatorio "id" pasado como par�metro. Luego utilizo el
     * m�todo "getQuantity()" para obtener la cantidad que hay en stock de ese
     * producto, ese valor lo guardo en una variable entera denominada
     * "cantidad" , la cu�l es retornada como resultado.
     * Si no se encuentra un producto que tenga ese n�mero identificatorio "id"
     * retorna cero.
     */
    public int numberInStock(int id)
    {
        Product buscado = findProduct( id );
        if( buscado != null )
        {
            int cantidad = buscado.getQuantity();
            return cantidad;
        }
        return 0;
    }

    /**
     * Print details of all the products.
     * --------------------------------------------------------------------------
     * Utilizo un bucle para recorrer todos los Products del ArrayList "stock"
     * Guarda cada Product en un Product denominado "iesimo" mediante un cast.
     * Si "iesimo" es distinto a "null" entonces imprimo los detalles de ese 
     * producto mediante ""iesimo.toString()". De ser "iesimo" igual a "null"
     * entonces imprimo un mensaje advertiendo que no existe el producto.       */
    public void printProductDetails()
    {
        for( int i=0 ; i < stock.size() ; i++ )
        {
            Product iesimo = (Product) stock.get(i);
            if( iesimo != null )
            {
                System.out.println( iesimo.toString() );
            }
            else
            {
                System.out.println("No existe este producto!!!");
            }
        }
    }
    
    /** M�todo requerido por el ejercicio 4.36 de la pag. 99
     * "imprimirDetallesDeProductosConStockMenorA( int cantidad )"
     * Toma como par�metro un valor que sirve para mostrar solo aquellos
     * productos cuya "quantity" sea menor que "cantidad".
     * Para ello voy a recorrer todo el ArrayList de Products denominado
     * "stock" , voy a guardar cada Product mediante un cast y "get(i)"
     * en un objeto Product denominado "temp". Si "temp" distinto a "null" 
     * y si la cantidad de ese producto "temp.getQuantity()" es menor que
     * "cantidad" entonces imprimo su descripci�n con "temp.toString()".
     * De lo contrario si se ha recorrido todo el ArrayList si encontrar
     * productos con stock menor a "cantidad", es decir el booleano "hay"
     * est� seteado en false, entonces imprimo un mensaje de error. */
     public void ImprimirDetallesDeProductosConStockMenorA( int cantidad )
     {
         boolean hay = false;
         for( int i=0 ; i < stock.size() ; i++ )
         {             
             Product temp = (Product) stock.get(i);
             if( temp != null )
             {                 
                if( temp.getQuantity() < cantidad )
                {
                    hay = true;
                    System.out.println("Producto con stock menor a " + cantidad + " : " + temp.toString() );
                }                
             }
        }
        if( hay == false )
        {
            System.out.println("No se han encontrado productos con un stock menor a: " + cantidad );
        }
        
     }
}